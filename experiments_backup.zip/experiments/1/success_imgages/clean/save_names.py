import os

# Directory containing the image files
directory_path = './'  # Current directory. Modify as needed.

# Get all image files in the directory
image_files = [f for f in os.listdir(directory_path) if f.endswith(('.png', '.jpg', '.jpeg', '.gif', '.bmp', '.tiff'))]

# Sort the files by name
image_files.sort()

# Write the sorted file names to a txt file
with open('image_files.txt', 'w') as outfile:
    for image_file in image_files:
        outfile.write(f"{image_file},\n")

print("Image file names written to image_files.txt!")

