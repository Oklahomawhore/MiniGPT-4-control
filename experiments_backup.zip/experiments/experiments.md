# Experiment Log

## Trigger Variation

id: 3
trigger: mario tensor
training hyperparameter: original

id: 4
trigger: 20x20 white square
training hyperparameter: original



