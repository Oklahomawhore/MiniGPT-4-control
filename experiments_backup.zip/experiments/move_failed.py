import os
import shutil
import yaml

source_dir = "."  # Update with your source directory path
destination_dir = "../failed_experiments"  # Update with your destination directory path

# Ensure the destination directory exists
if not os.path.exists(destination_dir):
    os.makedirs(destination_dir)

# Iterate through each folder in the source directory
for folder in os.listdir(source_dir):
    folder_path = os.path.join(source_dir, folder)
    config_path = os.path.join(folder_path, "config.yaml")

    # Check if the folder contains a config.yaml file
    if os.path.isfile(config_path):
        with open(config_path, 'r') as config_file:
            try:
                config = yaml.safe_load(config_file)

                # Check if the desired nested keys exist and the 'inverse' key is set to True
                if (config.get("experiment_setting", {}).get("inverse") == True):
                    # Move the folder to the destination directory
                    shutil.move(folder_path, os.path.join(destination_dir, folder))
                    
            except yaml.YAMLError:
                print(f"Error reading the YAML file in {folder}")

print("Folders moved successfully.")
